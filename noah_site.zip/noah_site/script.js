// set active nav link
(function(){
  const path = window.location.pathname.split('/').pop() || 'index.html';
  const links = document.querySelectorAll('nav a');
  links.forEach(a => {
    const href = a.getAttribute('href');
    if((path === '' && href.endsWith('index.html')) || href.endsWith(path)){
      a.classList.add('active');
    }
  });
})();

// optional: smooth anchor scrolling
document.addEventListener('click', (e)=>{
  const a = e.target.closest('a[href^="#"]');
  if(!a) return;
  const el = document.querySelector(a.getAttribute('href'));
  if(!el) return;
  e.preventDefault();
  el.scrollIntoView({behavior:'smooth', block:'start'});
});

// simple dark-mode respects prefers-color-scheme (already designed dark)
